from __future__ import annotations

import contextlib
import importlib
import json
import math
import subprocess
import sys
import zipfile
from dataclasses import replace

import pytest
import torch
from benchmarks import compact_occupancy_refinement_factorial as factorial

from rtgs.core.camera import Camera
from rtgs.core.observation2d import GaussianObservationField, GaussianPointProposal
from rtgs.data.reconstruction_inputs import ReconstructionInputs


@contextlib.contextmanager
def _without_preloaded_rgb_modules():
    saved = {
        name: module
        for name, module in tuple(sys.modules.items())
        if factorial.RGBAccessGuard._forbidden_module(name)
    }
    for name in saved:
        sys.modules.pop(name, None)
    try:
        yield
    finally:
        sys.modules.update(saved)


def _field(view_name: str, *, proxy: bool = False) -> GaussianObservationField:
    return GaussianObservationField(
        width=8,
        height=6,
        means=torch.tensor([[2.5, 2.5], [5.5, 3.5]]),
        log_scales=torch.log(torch.tensor([[0.8, 1.1], [1.0, 0.7]])),
        rotations=torch.tensor([0.2, -0.3]),
        colors=(torch.ones(2, 3) if proxy else torch.tensor([[0.2, 0.4, 0.6], [0.7, 0.3, 0.1]])),
        amplitudes=torch.tensor([0.8, 0.4]) if not proxy else torch.tensor([0.9, 0.6]),
        filter_variance=torch.tensor([0.1, 0.2]),
        blend_mode="normalized",
        epsilon=1e-8,
        sigma_cutoff=3.0,
        support_fade_alpha=0.0,
        aa_dilation=0.0,
        view_id=view_name,
        fit_window=(0, 0, 8, 6),
        n_init=2,
        provider="synthetic_fixture",
    )


def _camera() -> Camera:
    return Camera(
        fx=7.0,
        fy=7.0,
        cx=4.0,
        cy=3.0,
        width=8,
        height=6,
        R=torch.eye(3),
        t=torch.tensor([0.0, 0.0, 2.0]),
    )


def _inputs(*, proxy: bool = False) -> ReconstructionInputs:
    fields = [_field(name, proxy=proxy) for name in factorial.EXPECTED_VIEWS]
    return ReconstructionInputs(
        observations=fields,
        cameras=[_camera() for _ in fields],
        view_names=list(factorial.EXPECTED_VIEWS),
        name="fixture",
    )


def _test_bank_sample():
    field = _field(factorial.EXPECTED_VIEWS[0])
    evaluation_seed = factorial.TEST_EVALUATION_SEEDS[0]
    generator_seed = factorial.evaluation_bank_seed(
        evaluation_seed,
        factorial.EXPECTED_VIEWS[0],
        "uniform",
    )
    samples = GaussianPointProposal(field, field).sample(
        factorial.BANK_ATTEMPTS,
        uniform_fraction=1.0,
        generator=torch.Generator(device="cpu").manual_seed(generator_seed),
    )
    color = field.query(samples.xy, component_chunk=640).color
    return field, evaluation_seed, generator_seed, samples, color


def _validate_test_bank(field, evaluation_seed, generator_seed, samples, color):
    factorial._validate_bank_invariants(
        evaluation_seed=evaluation_seed,
        seed_domain="focused_test",
        view_index=0,
        view_name=factorial.EXPECTED_VIEWS[0],
        kind="uniform",
        generator_seed=generator_seed,
        product=field,
        samples=samples,
        color=color,
        require_color=color is not None,
    )


def _decision_records(d_over_b: float = 0.8, u_over_b: float = 1.0):
    result = {}
    for seed in factorial.TEST_TRAIN_SEEDS:
        arms = {}
        for arm in factorial.ARMS:
            scale_q = d_over_b if arm == "D" else 1.0
            scale_u = u_over_b if arm == "D" else 1.0
            arms[arm] = {
                "checkpoint_metrics": {
                    str(step): {
                        "J_Q": base * scale_q,
                        "J_U": base * scale_u,
                    }
                    for step, base in zip(
                        factorial.CHECKPOINTS,
                        (1.0, 0.8, 0.6, 0.5),
                        strict=True,
                    )
                }
            }
        result[seed] = arms
    return result


def test_evaluation_bank_seed_is_stable_and_view_kind_isolated():
    first, second = factorial.TEST_EVALUATION_SEEDS
    value = factorial.evaluation_bank_seed(first, "C0001", "uniform")
    assert value == factorial.evaluation_bank_seed(first, "C0001", "uniform")
    assert 0 <= value < 2**63
    assert value != factorial.evaluation_bank_seed(first, "C0008", "uniform")
    assert value != factorial.evaluation_bank_seed(first, "C0001", "proposal")
    assert value != factorial.evaluation_bank_seed(second, "C0001", "uniform")


def test_log_auc_and_geometric_mean_use_frozen_math():
    assert factorial.log_auc([2.0] * 4) == pytest.approx(math.log(2.0))
    assert factorial.geometric_mean([0.5, 2.0]) == pytest.approx(1.0)
    with pytest.raises(ValueError):
        factorial.log_auc([1.0, 2.0])
    with pytest.raises(ValueError):
        factorial.geometric_mean([0.0])


def test_decision_passes_only_when_every_gate_passes():
    passed = factorial.compute_decision(
        _decision_records(), [0.99] * 21, seeds=factorial.TEST_TRAIN_SEEDS
    )
    assert passed["decision"] == "AUTHORIZE_DENSITY_FOLLOWUP"
    assert all(passed["gates"].values())

    active_failure = factorial.compute_decision(
        _decision_records(),
        [0.94] + [0.99] * 20,
        seeds=factorial.TEST_TRAIN_SEEDS,
    )
    assert active_failure["decision"] == "NO_REFINEMENT_TARGET_PROMOTION"
    assert not active_failure["gates"]["active_fraction_each_ge_0_95"]

    uniform_failure = factorial.compute_decision(
        _decision_records(d_over_b=0.8, u_over_b=1.11),
        [0.99] * 21,
        seeds=factorial.TEST_TRAIN_SEEDS,
    )
    assert uniform_failure["decision"] == "NO_REFINEMENT_TARGET_PROMOTION"
    assert not uniform_failure["gates"]["final_J_U_each_ratio_le_1_10"]


def test_raw_proxy_alignment_and_product_amplitudes_are_exact():
    teachers = _inputs()
    proxies = _inputs(proxy=True)
    products, records = factorial.build_product_fields(teachers, proxies)
    assert [record["m_opt_2d"] for record in records] == [2] * 7
    for teacher, proxy, product in zip(
        teachers.observations, proxies.observations, products, strict=True
    ):
        assert torch.equal(product.amplitudes, teacher.amplitudes * proxy.amplitudes)
        assert torch.equal(product.colors, torch.ones_like(product.colors))
        assert product.color_grads is None


def test_product_construction_retains_variable_per_view_m_opt_list():
    teachers = _inputs()
    proxies = _inputs(proxy=True)
    teacher = teachers.observations[0]
    proxy = proxies.observations[0]
    teacher_three = replace(
        teacher,
        means=torch.cat([teacher.means, teacher.means[:1] + torch.tensor([[0.2, 0.1]])]),
        log_scales=torch.cat([teacher.log_scales, teacher.log_scales[:1]]),
        rotations=torch.cat([teacher.rotations, teacher.rotations[:1]]),
        colors=torch.cat([teacher.colors, teacher.colors[:1]]),
        amplitudes=torch.cat([teacher.amplitudes, torch.tensor([0.2])]),
        filter_variance=torch.cat([teacher.filter_variance, teacher.filter_variance[:1]]),
    )
    proxy_three = replace(
        proxy,
        means=teacher_three.means,
        log_scales=teacher_three.log_scales,
        rotations=teacher_three.rotations,
        colors=torch.ones(3, 3),
        amplitudes=torch.tensor([0.9, 0.6, 0.5]),
        filter_variance=teacher_three.filter_variance,
    )
    variable_teachers = replace(teachers, observations=[teacher_three, *teachers.observations[1:]])
    variable_proxies = replace(proxies, observations=[proxy_three, *proxies.observations[1:]])
    products, records = factorial.build_product_fields(variable_teachers, variable_proxies)
    assert [record["m_opt_2d"] for record in records] == [3, 2, 2, 2, 2, 2, 2]
    assert [field.n for field in products] == [3, 2, 2, 2, 2, 2, 2]


def test_raw_proxy_alignment_rejects_geometry_scalar_and_camera_mismatch():
    teachers = _inputs()
    proxies = _inputs(proxy=True)
    bad_geometry = replace(proxies.observations[0], means=proxies.observations[0].means.flip(0))
    with pytest.raises(factorial.ProtocolInvalid, match="positionally misaligned"):
        factorial.validate_proxy_alignment(
            teachers,
            replace(proxies, observations=[bad_geometry, *proxies.observations[1:]]),
        )

    bad_scalar = replace(proxies.observations[0], amplitudes=torch.tensor([1.1, 0.6]))
    with pytest.raises(factorial.ProtocolInvalid, match=r"outside \[0,1\]"):
        factorial.validate_proxy_alignment(
            teachers,
            replace(proxies, observations=[bad_scalar, *proxies.observations[1:]]),
        )

    camera = replace(proxies.cameras[0], fx=8.0)
    with pytest.raises(factorial.ProtocolInvalid, match="camera differs"):
        factorial.validate_proxy_alignment(
            teachers,
            replace(proxies, cameras=[camera, *proxies.cameras[1:]]),
        )

    bad_blend = replace(proxies.observations[0], blend_mode="additive")
    with pytest.raises(factorial.ProtocolInvalid, match="support/canvas semantics differ"):
        factorial.validate_proxy_alignment(
            teachers,
            replace(proxies, observations=[bad_blend, *proxies.observations[1:]]),
        )

    bad_n_init = replace(proxies.observations[0], n_init=3)
    with pytest.raises(factorial.ProtocolInvalid, match="support/canvas semantics differ"):
        factorial.validate_proxy_alignment(
            teachers,
            replace(proxies, observations=[bad_n_init, *proxies.observations[1:]]),
        )


def test_bank_archive_roundtrip_hashes_every_tensor(tmp_path):
    teachers = _inputs()
    products, _ = factorial.build_product_fields(teachers, _inputs(proxy=True))
    path = tmp_path / "banks.npz"
    seed = factorial.TEST_EVALUATION_SEEDS[0]
    record = factorial.generate_test_bank_archive(seed, teachers, products, path)
    loaded, metadata = factorial.load_bank_archive(
        path,
        seed,
        expected_seed_domain="focused_test",
    )
    assert record["sha256"] == factorial.sha256_file(path)
    assert len(loaded) == 7
    assert metadata["evaluation_seed"] == seed
    assert metadata["seed_domain"] == "focused_test"
    for view in loaded:
        assert view["uniform"]["xy"].shape == (4096, 2)
        assert view["uniform"]["active"].all()
        assert view["proposal"]["active"].shape == (4096,)

    with path.open("r+b") as stream:
        stream.seek(-32, 2)
        byte = stream.read(1)
        stream.seek(-1, 1)
        stream.write(bytes([byte[0] ^ 1]))
    with pytest.raises((factorial.ProtocolInvalid, zipfile.BadZipFile)):
        factorial.load_bank_archive(
            path,
            seed,
            expected_seed_domain="focused_test",
        )


def test_bank_invariant_diagnostic_retains_nonfinite_sample_context():
    field, evaluation_seed, generator_seed, samples, color = _test_bank_sample()
    proposal_density = samples.proposal_density.clone()
    proposal_density[11] = torch.inf
    bad_samples = replace(samples, proposal_density=proposal_density)
    with pytest.raises(factorial.BankInvariantError) as captured:
        _validate_test_bank(field, evaluation_seed, generator_seed, bad_samples, color)
    diagnostic = captured.value.diagnostic
    assert diagnostic["evaluation_seed"] == factorial.TEST_EVALUATION_SEEDS[0]
    assert diagnostic["seed_domain"] == "focused_test"
    assert diagnostic["view_name"] == factorial.EXPECTED_VIEWS[0]
    assert diagnostic["kind"] == "uniform"
    assert diagnostic["generator_seed"] == generator_seed
    assert diagnostic["first_failing_index"] == 11
    assert diagnostic["first_failing_xy"] == pytest.approx(samples.xy[11].tolist())
    assert diagnostic["fit_window"] == list(field.fit_window)
    assert diagnostic["predicate_counts"]["nonfinite_proposal_density_count"] == 1
    assert diagnostic["tensor_sha256"]["proposal_density"] == factorial.tensor_hash(
        proposal_density
    )


def test_bank_invariant_diagnostic_retains_nonfinite_xy_context():
    field, evaluation_seed, generator_seed, samples, color = _test_bank_sample()
    xy = samples.xy.clone()
    xy[13, 0] = torch.inf
    bad_samples = replace(samples, xy=xy)
    with pytest.raises(factorial.BankInvariantError) as captured:
        _validate_test_bank(field, evaluation_seed, generator_seed, bad_samples, color)
    diagnostic = captured.value.diagnostic
    assert diagnostic["first_failing_index"] == 13
    assert diagnostic["first_failing_xy"] == [None, float(xy[13, 1])]
    assert diagnostic["predicate_counts"]["nonfinite_xy_count"] == 1
    assert diagnostic["predicate_counts"]["uniform_coordinate_outside_half_open_count"] == 1
    assert diagnostic["tensor_sha256"]["xy"] == factorial.tensor_hash(xy)


def test_bank_invariant_diagnostic_retains_nonfinite_color_in_terminal_failure():
    field, evaluation_seed, generator_seed, samples, color = _test_bank_sample()
    color = color.clone()
    color[17, 2] = torch.nan
    with pytest.raises(factorial.BankInvariantError) as captured:
        _validate_test_bank(field, evaluation_seed, generator_seed, samples, color)
    diagnostic = captured.value.diagnostic
    assert diagnostic["first_failing_index"] == 17
    assert diagnostic["first_failing_xy"] == pytest.approx(samples.xy[17].tolist())
    assert diagnostic["predicate_counts"]["nonfinite_color_count"] == 1
    assert diagnostic["tensor_sha256"]["color"] == factorial.tensor_hash(color)
    terminal = factorial.bounded_failure(captured.value, stage="test_bank_generation")
    assert terminal["scientific_decision"] == "UNAVAILABLE"
    assert terminal["promotion_authorized"] is False
    assert terminal["failure"]["bank_invariant"] == diagnostic


def test_bank_invariant_diagnostic_structures_wrong_sample_shape():
    field, evaluation_seed, generator_seed, samples, _color = _test_bank_sample()
    bad_samples = replace(samples, xy=samples.xy[:-1])
    with pytest.raises(factorial.BankInvariantError) as captured:
        _validate_test_bank(field, evaluation_seed, generator_seed, bad_samples, None)
    diagnostic = captured.value.diagnostic
    assert diagnostic["first_failing_index"] == factorial.BANK_ATTEMPTS - 1
    assert diagnostic["first_failing_xy"] is None
    assert diagnostic["predicate_counts"]["shape_mismatch_count"] == 1
    assert diagnostic["shape_mismatches"]["xy"] == {
        "expected": [factorial.BANK_ATTEMPTS, 2],
        "actual": [factorial.BANK_ATTEMPTS - 1, 2],
    }
    assert diagnostic["tensor_sha256"]["xy"] == factorial.tensor_hash(bad_samples.xy)


def test_rgb_guard_has_negative_controls_and_no_false_positive(tmp_path):
    guard = factorial.RGBAccessGuard()
    with _without_preloaded_rgb_modules(), guard:
        assert json.loads('{"compact": true}')["compact"] is True
        (tmp_path / "allowed.json").write_text("{}", encoding="utf-8")
    assert guard.record() == {
        "source_rgb_open_attempts": 0,
        "forbidden_import_attempts": 0,
        "negative_control_denials": 3,
        "forbidden_modules_at_entry": [],
        "forbidden_modules_at_exit": [],
        "passed": True,
    }


def test_rgb_guard_counts_real_forbidden_attempt(tmp_path):
    guard = factorial.RGBAccessGuard()
    with _without_preloaded_rgb_modules(), guard, pytest.raises(PermissionError):
        (tmp_path / "forbidden.png").read_bytes()
    assert guard.record()["source_rgb_open_attempts"] == 1
    assert guard.record()["passed"] is False


def test_rgb_guard_denies_importlib_bypass_and_counts_attempt():
    guard = factorial.RGBAccessGuard()
    with _without_preloaded_rgb_modules(), guard, pytest.raises(ImportError):
        importlib.import_module("rtgs.data.calibrated")
    assert guard.record()["forbidden_import_attempts"] == 1
    assert "rtgs.data.calibrated" not in sys.modules


def test_rgb_guard_fails_if_forbidden_module_crosses_entry_or_exit():
    sys.modules["PIL.Image"] = object()
    try:
        with pytest.raises(factorial.ProtocolInvalid, match="before denial boundary"):
            factorial.RGBAccessGuard().__enter__()
    finally:
        sys.modules.pop("PIL.Image", None)

    with _without_preloaded_rgb_modules():
        guard = factorial.RGBAccessGuard()
        try:
            with pytest.raises(factorial.ProtocolInvalid, match="crossed denial boundary"), guard:
                sys.modules["PIL.Image"] = object()
        finally:
            sys.modules.pop("PIL.Image", None)


def test_paired_worker_validation_checks_sampling_and_target_hashes(tmp_path, monkeypatch):
    monkeypatch.setattr(factorial, "ROOT", tmp_path)
    base = {key: f"same-{key}" for key in factorial.PAIRED_SAMPLE_KEYS if key not in {"view_index"}}
    base["view_index"] = 0
    left_steps = []
    right_steps = []
    for step in range(140):
        left_steps.append(
            {
                **base,
                "step": step + 1,
                "target_density_sha256": f"left-target-{step}",
                "importance_sha256": f"left-importance-{step}",
            }
        )
        right_steps.append(
            {
                **base,
                "step": step + 1,
                "target_density_sha256": f"right-target-{step}",
                "importance_sha256": f"right-importance-{step}",
            }
        )
    factorial.exclusive_json(tmp_path / "left.json", {"steps": left_steps})
    factorial.exclusive_json(tmp_path / "right.json", {"steps": right_steps})
    left = {"arm": "A", "history": {"path": "left.json"}}
    right = {"arm": "C", "history": {"path": "right.json"}}
    result = factorial.validate_paired_workers(left, right)
    assert result["steps"] == 140
    assert result["target_hash_difference_counts"] == {
        "target_density_sha256": 140,
        "importance_sha256": 140,
    }
    right_steps[10]["xy_sha256"] = "different"
    (tmp_path / "right2.json").write_text(json.dumps({"steps": right_steps}), encoding="utf-8")
    with pytest.raises(factorial.ProtocolInvalid, match="xy_sha256"):
        factorial.validate_paired_workers(left, {"arm": "C", "history": {"path": "right2.json"}})

    partially_equal = [dict(step) for step in right_steps]
    partially_equal[10]["xy_sha256"] = left_steps[10]["xy_sha256"]
    partially_equal[10]["target_density_sha256"] = left_steps[10]["target_density_sha256"]
    (tmp_path / "right3.json").write_text(json.dumps({"steps": partially_equal}), encoding="utf-8")
    with pytest.raises(factorial.ProtocolInvalid, match="at every step"):
        factorial.validate_paired_workers(left, {"arm": "C", "history": {"path": "right3.json"}})


def test_step_zero_requires_exact_snapshot_and_metrics():
    records = {
        arm: {
            "snapshots": [{"semantic_sha256": "same"}],
            "checkpoint_metrics": {"0": {"J_U": 1.0, "J_Q": 2.0}},
        }
        for arm in factorial.ARMS
    }
    assert factorial.validate_step_zero(records)["all_four_arms_exact"] is True
    records["D"]["checkpoint_metrics"]["0"]["J_Q"] = 2.1
    with pytest.raises(factorial.ProtocolInvalid, match="step-zero"):
        factorial.validate_step_zero(records)


def test_terminal_failure_payload_is_finite_and_bounded():
    payload = factorial.bounded_failure(
        RuntimeError("x" * 5000), stage="test", attempt_sha256="a" * 64
    )
    encoded = factorial.canonical_bytes(payload)
    assert b'"status":"FAIL"' in encoded
    assert payload["decision"] == "UNAVAILABLE"
    assert payload["scientific_decision"] == "UNAVAILABLE"
    assert payload["promotion_authorized"] is False
    assert len(payload["failure"]["message"]) == 2000
    with pytest.raises(ValueError):
        factorial.canonical_bytes({"bad": float("nan")})

    bank_error = factorial.BankInvariantError(
        "boundary",
        {
            "seed_domain": "focused_test",
            "view_name": "C0001",
            "first_failing_index": 7,
            "first_failing_xy": [8.0, 2.0],
        },
    )
    bank_payload = factorial.bounded_failure(bank_error, stage="test_bank")
    assert bank_payload["failure"]["bank_invariant"] == bank_error.diagnostic


def test_run_entry_reports_terminal_serialization_fallback_as_failure(tmp_path, monkeypatch):
    seal = tmp_path / "seal.json"
    attempt = tmp_path / "attempt.json"
    result = tmp_path / "result.json"
    factorial.exclusive_json(seal, {"status": "SEALED"})
    monkeypatch.setattr(factorial, "SEAL", seal)
    monkeypatch.setattr(factorial, "ATTEMPT", attempt)
    monkeypatch.setattr(factorial, "RESULT", result)
    monkeypatch.setattr(factorial, "_namespace_clean_for_run", lambda: True)
    monkeypatch.setattr(
        factorial,
        "verify_seal",
        lambda: {"preregistration_sha256": "p" * 64, "config": {}},
    )
    monkeypatch.setattr(
        factorial,
        "execute_attempt",
        lambda **_kwargs: {"status": "PASS", "nonfinite": float("nan")},
    )
    assert factorial.run_entry() == 2
    written = factorial.strict_json(result)
    assert written["status"] == "FAIL"
    assert written["failure"]["stage"] == "terminal_result_serialization"


def test_run_entry_rechecks_namespace_before_attempt_publication(tmp_path, monkeypatch):
    attempt = tmp_path / "attempt.json"
    monkeypatch.setattr(factorial, "ATTEMPT", attempt)
    checks = iter((True, False))
    monkeypatch.setattr(factorial, "_namespace_clean_for_run", lambda: next(checks))
    monkeypatch.setattr(
        factorial,
        "verify_seal",
        lambda: {"preregistration_sha256": "p" * 64, "config": {}},
    )
    monkeypatch.setattr(factorial, "SEAL", tmp_path / "seal.json")
    (tmp_path / "seal.json").write_text("{}", encoding="utf-8")
    with pytest.raises(factorial.ProtocolInvalid, match="before attempt publication"):
        factorial.run_entry()
    assert not attempt.exists()


def test_fresh_harness_import_does_not_preload_rgb_capable_modules():
    script = """
import json
import sys
from benchmarks import compact_occupancy_refinement_factorial as factorial
forbidden = [
    name for name in sys.modules
    if name == 'PIL' or name.startswith('PIL.')
    or name in {'rtgs.data.calibrated', 'rtgs.data.scene'}
]
print(json.dumps({
    'forbidden': sorted(forbidden),
    'unbound_local_sources': factorial.unbound_loaded_local_sources(),
    'module_origin_violations': factorial.module_origin_violations(),
}))
"""
    completed = subprocess.run(
        [sys.executable, "-c", script],
        cwd=factorial.ROOT,
        text=True,
        capture_output=True,
        timeout=30,
        check=True,
    )
    assert json.loads(completed.stdout) == {
        "forbidden": [],
        "module_origin_violations": [],
        "unbound_local_sources": [],
    }


def test_frozen_config_exposes_no_dense_checkpoint_evaluation():
    config = factorial.frozen_test_config("D", factorial.TEST_TRAIN_SEEDS[0])
    assert config.device == "cuda:0"
    assert config.schedule_mode == "balanced_cycle"
    assert config.target_mode == "proposal_attempt"
    assert config.evaluate_checkpoint_risks is False
    assert config.checkpoints == (0, 35, 70, 140)
    assert config.outer_microbatch == config.attempts_per_step == 128

    common = factorial.common_train_config_record(config)
    optimizer = factorial.optimizer_record(common)
    assert common["proposal_mode"] == "area_gaussian"
    assert common["lr_means"] == 1.6e-4
    assert common["sh_degree"] == 0
    assert common["sh_color_activation"] == "hard"
    assert common["kernel_support_mode"] == "hard"
    assert common["visibility_margin_sigma"] == 3.0
    assert optimizer["betas"] == [0.9, 0.999]
    assert optimizer["foreach"] is False
    assert not (
        set(factorial.TRAIN_SEEDS + factorial.EVALUATION_SEEDS)
        & set(factorial.TEST_TRAIN_SEEDS + factorial.TEST_EVALUATION_SEEDS)
    )


def test_review_gate_requires_one_exact_standalone_pass_line(tmp_path, monkeypatch):
    review = tmp_path / "review.md"
    monkeypatch.setattr(factorial, "IMPLEMENTATION_REVIEW", review)
    monkeypatch.setattr(factorial, "reviewed_source_hashes", lambda: ({}, "a" * 64))
    aggregate = f"{factorial.REVIEW_AGGREGATE_PREFIX}{'a' * 64}"
    review.write_text(f"Verdict: FAIL\nThe string Verdict: PASS appears in prose.\n{aggregate}\n")
    assert factorial._review_passed() is False
    review.write_text(f"Verdict: PASS\n{aggregate}\n")
    assert factorial._review_passed() is True
    review.write_text(f"Verdict: PASS\nVerdict: PASS\n{aggregate}\n")
    assert factorial._review_passed() is False
    review.write_text(f"Verdict: PASS\n{factorial.REVIEW_AGGREGATE_PREFIX}{'b' * 64}\n")
    assert factorial._review_passed() is False
